﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Illusory Studios LLC")]
[assembly: AssemblyCopyright("Copyright © 2010-2013 James F. Bellinger <http://www.zer7.com/software/hidsharp>")]
[assembly: AssemblyDescription("HID test program")]
[assembly: AssemblyProduct("HidSharp")]
[assembly: AssemblyTitle("HidSharp.Test")]
[assembly: AssemblyFileVersion("1.3.0.0")]
[assembly: AssemblyVersion("1.3.0.0")]

[assembly: ComVisible(false)]
[assembly: Guid("2F0DC374-5974-49E6-A7C6-5FFDEDE5E21D")]
